﻿using UnityEngine;
using System.Collections;

public class HandRaiseDetector : MonoBehaviour {
	public float threshold = 2f;
	public GameObject leftHand;
	private bool leftHandRaised;
	public GameObject rightHand;
	private bool rightHandRaised;
	public GameObject head;
	private bool bothHandsRaised;

	public GameObject rightElbow;
	public GameObject leftElbow;

	private bool error;
	private TextMesh text;

	private Vector3 leftHandPosition;
	private Vector3 rightHandPosition;
	private Vector3 leftElbowPosition;
	private Vector3 rightElbowPosition;

	private bool defenseMode = false;

	// Use this for initialization
	void Start () {
		leftHandRaised = false;
		rightHandRaised = false;
		text = gameObject.GetComponent<TextMesh>();

		error = false;
		if (leftHand == null) {
			print("Error: No left hand game object assigned.");
			error = true;
		}  
		if (rightHand == null) {
			print("Error: No right hand game object assigned.");
			error = true;
		}
		if (rightElbow == null) {
			print("Error: No right elbow game object assigned.");
			error = true;
		}
		if (leftElbow == null) {
			print("Error: No left elbow game object assigned.");
			error = true;
		}
		if (head == null) {
			print("Error: No head game object assigned.");
			error = true;
		}


	}
	
	// Update is called once per frame
	void Update () {

		if (error) {
			return;
		}

		checkBlock ();

		if (!defenseMode) {
			checkKameHameHa;()
		}

		showNotifier (leftHand.transform.position.ToString () + " " + rightHand.transform.position.ToString ());
	}

	void checkBlock() {

		// arms shall cross

		if (handsCrossedThreshold ()) {

			if (!defenseMode) {
				defenseMode = true;
				showNotifier ("defenseMode!");
			}

		} else if (!handsCrossed ()) {

			if (defenseMode) {
				defenseMode = false;
				showNotifier ("");
			}
		}

	}

	void checkKameHameHa() {

		// lets honor son goku!

	}


	void showNotifier(string message){
		text.text = message;
	}

	bool handsCrossedThreshold() {
		return handsCrossedWrapper (threshold);
	}

	bool handsCrossed() {
		return handsCrossedWrapper (0f);
	}

	bool handsCrossedWrapper(float thresh) {
		leftHandPosition = leftHand.transform.position;
		rightHandPosition = rightHand.transform.position;
		rightElbowPosition = rightElbow.transform.position;
		leftElbowPosition = leftElbow.transform.position;

		return leftHandPosition.x < rightHandPosition.x + thresh
			&& rightElbowPosition.x < leftElbowPosition.x + thresh
			&& leftHandPosition.y > rightElbowPosition.y + thresh
			&& rightHandPosition.y > leftElbowPosition.y + thresh;
	}

	bool isLeftHandRaised(float thresh) {
		return leftHand.transform.position.y > head.transform.position.y + thresh;
	}

	bool isRightHandRaised(float thresh) {
		return rightHand.transform.position.y > head.transform.position.y + thresh;
	}

	bool isLeftElbowRaised(float thresh) {
		return leftElbow.transform.position.y > head.transform.position.y + thresh;
	}
	
	bool isRightElbowRaised(float thresh) {
		return rightElbow.transform.position.y > head.transform.position.y + thresh;
	}

	bool isLeftArmRaised(float thresh) {
		return isLeftHandRaised (thresh) && isLeftElbowRaised (thresh);
	}

	bool isRightArmRaised(float thresh) {
		return isRightHandRaised (thresh) && isRightElbowRaised(thresh);
	}

}

